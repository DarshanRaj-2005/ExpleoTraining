window.AISellerSettings = {
    agent_id: '5a13adeb-10f9-4938-9372-a60cc486ab71',
  };
  
  // Then load the widget loader script
  (function () {
    var w = window;
    var ew = w.AISeller;
    if (typeof ew === 'function') {
      ew('update', w.AISellerSettings);
    } else {
      var d = document;
      var i = function () {
        i.q.push(arguments);
      };
      i.q = [];
      i.q.push(['update', w.AISellerSettings]);
      w.AISeller = i;
      var l = function () {
        var s = d.createElement('script');
        s.type = 'text/javascript';
        s.async = true;
        s.src = 'https://d33t2173eag6fx.cloudfront.net/script/app/inbound-se-script/ai-seller.js';
        var x = d.getElementsByTagName('script')[0];
        x.parentNode.insertBefore(s, x);
      };
      if (document.readyState === 'complete') {
        l();
      } else if (w.attachEvent) {
        w.attachEvent('onload', l);
      } else {
        w.addEventListener('load', l, false);
      }
    }
  })();
  